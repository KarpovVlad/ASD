package Interfaces;
import java.util.ArrayList;

public interface ISearcher {
    ArrayList<Integer> search(String text, String pattern);
}