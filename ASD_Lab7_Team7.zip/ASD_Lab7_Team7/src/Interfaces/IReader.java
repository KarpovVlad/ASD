package Interfaces;

public interface IReader {
        String read(String filename);
    }
