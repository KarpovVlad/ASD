package Classes;
import Interfaces.ISearcher;
import java.util.ArrayList;
public class Searcher implements ISearcher {
    private int getHash(String stringers, int length) {
        String stringToHash = stringers.substring(0, length);
        return stringToHash.hashCode();
    }
    @Override
    public ArrayList<Integer> search(String text, String pattern) {
        int i2 = pattern.length();
        int i3 = text.length();
        ArrayList<Integer> result = new ArrayList<>(i3 - i2);
        int patternHash = getHash(pattern, i2);
        int strHash = getHash(text, i2);
        for (int i = 0; i < i3 - i2 + 1; i++) {
            if (patternHash == strHash) {
                int i1 = 0;
                for (int j = i; j < i + i2; j++, i1++) {
                    if (text.charAt(j) != pattern.charAt(i1)) {
                        break;
                    }
                }
                if (i1 == i2) {
                    result.add(i);
                }
            }
            else{
                strHash = getHash(text.substring(i + 1, i + i2 + 1), i2);
            }
        }
        return result;
    }
}