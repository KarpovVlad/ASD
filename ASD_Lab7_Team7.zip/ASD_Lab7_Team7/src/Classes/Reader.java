package Classes;
import Interfaces.IReader;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
public class Reader implements IReader {
    @Override
    public String read(String filename) {
        StringBuilder strings = new StringBuilder();
        String temp;
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            while ((temp = reader.readLine()) != null) {
                strings.append(temp);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return strings.toString();
    }
}