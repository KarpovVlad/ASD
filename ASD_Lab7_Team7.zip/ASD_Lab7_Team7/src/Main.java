import Classes.Reader;
import Classes.Searcher;
import Interfaces.IReader;
import Interfaces.ISearcher;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        IReader reader = new Reader();
        ISearcher searcher = new Searcher();
        String text = reader.read("files\\text.txt");
        String segment = reader.read("files\\segment.txt");
        long ms = System.currentTimeMillis();
        ArrayList<Integer> res = searcher.search(text, segment);
        ms = System.currentTimeMillis() - ms;
        System.out.println("Кількість \"" + segment + "\" в тексті: " + res.size());
        for(int element : res){
            System.out.print(element + " ");
        }
        System.out.println();
        System.out.println("Час: " + ms + " мс");
    }
}