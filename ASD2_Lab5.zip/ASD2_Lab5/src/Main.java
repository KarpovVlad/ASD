public class Main {
    static Team7HashMap<Integer> hashMap = new Team7HashMap<>();

    public static void main(String[] args){
        insertHash();
        deleteHash();
        findHash();

    }
    public static void insertHash(){
        long start = System.nanoTime();
        for ( int i = 1; i <= 100000 ;i++ )
        {
            hashMap.insert("" + i + "",i);
        }
        long end = System.nanoTime();
        System.out.println("Додавання: " + (end - start)/1000000 +" мс / 100000");

    }
    public static void deleteHash(){
        long start = System.nanoTime();
        for ( int i = 0; i < 100000 ;i++ )
        {
            hashMap.delete("" + i + "");
        }
        long end = System.nanoTime();
        System.out.println("Видалення: " + (end-start)/1000000 + " мс / 100000");
    }
    public static void findHash(){
        long start = System.nanoTime();
        for ( int i = 0; i < 100000 ;i += 2 )
        {
            hashMap.find("" + i + "");
        }
        long end = System.nanoTime();
        System.out.println("Пошук: " + (end-start)/1000000 + " мс / 100000");
    }




}