import java.util.ArrayList;

public class Team7HashMap<T> {

    private ArrayList<Nodus<T>> buckets;
    private int razmer;
    private int BucketsCounter;

    public Team7HashMap() {
        buckets = new ArrayList<>(16);
        BucketsCounter = 16;
        razmer = 0;

        for (int i = 0; i < BucketsCounter; i++)
            buckets.add(null);
    }

    private class Nodus<T> {
        String key;
        T value;

        Nodus<T> nextNodus;

        public Nodus(String key, T value) {
            this.key = key;

            this.value = value;
        }
    }

    public T find(String key) {
        Nodus<T> nodus = buckets.get(getIndexOfBuckets(key));
        while (nodus != null) {
            if (nodus.key.equals(key))
                return nodus.value;
            nodus = nodus.nextNodus;
        }
        return null;
    }


    public void delete(String key) {
        int bucketIndex = getIndexOfBuckets(key);
        Nodus<T> deleteNodus = buckets.get(bucketIndex);
        if (deleteNodus == null) return;
        Nodus<T> formerNodus = null;
        while (deleteNodus != null) {
            if (deleteNodus.key.equals(key))
                break;
            formerNodus = deleteNodus;
            deleteNodus = deleteNodus.nextNodus;
        }
        razmer -= 1;
        if (formerNodus != null) {
            if (deleteNodus == null) {
                return;
            }
            formerNodus.nextNodus = deleteNodus.nextNodus;
        } else {
            buckets.set(bucketIndex, deleteNodus.nextNodus);
        }
    }

    public void insert(String key, T value) {
        int bucketIndex = getIndexOfBuckets(key);
        Nodus<T> afterInserted = buckets.get(bucketIndex);
        while (afterInserted != null) {
            if (afterInserted.key.equals(key)) {
                afterInserted.value = value;
                return;
            }
            afterInserted = afterInserted.nextNodus;
        }
        razmer++;
        afterInserted = buckets.get(bucketIndex);
        Nodus<T> newNode = new Nodus(key, value);
        newNode.nextNodus = afterInserted;
        buckets.set(bucketIndex, newNode);
        if (!acceptLoadFactor()) {
            ensureCapacity();
        }
    }

    private void ensureCapacity() {
        ArrayList<Nodus<T>> temp = buckets;
        BucketsCounter *= 2;
        razmer = 0;
        buckets = new ArrayList<>(BucketsCounter);
        for (int i = 0; i < BucketsCounter; i++)
            buckets.add(null);
        for (Nodus<T> nodus : temp) {
            while (nodus != null) {
                insert(nodus.key, nodus.value);
                nodus = nodus.nextNodus;
            }
        }
    }
    private static int getHashCode(String key) {
        double RandomSmall = 67;       // Застосовано сайт Random.org
        double RandomBig = 45039465; // Застосовано сайт Random.org
        double multiplier = 1;
        int hashCode = 0;

        for (char i : key.toCharArray()) {
            hashCode += ((int) i) * multiplier % RandomBig;
            multiplier = multiplier * RandomSmall % RandomBig;
        }

        return hashCode;
    }

    private boolean acceptLoadFactor() {
        return (1.0 * razmer / BucketsCounter) <= 0.7;
    }
    private int getIndexOfBuckets(String key) {
        return Math.abs(getHashCode(key) % BucketsCounter);
    }

    public ArrayList<T> toArray() {
        ArrayList<T> result = new ArrayList<>();
        for (Nodus<T> nodus : buckets) {
            while (nodus != null) {
                result.add(nodus.value);
                nodus = nodus.nextNodus;
            }
        }
        return result;
    }


}